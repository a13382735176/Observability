"""Probe script: prove Copilot agent tool invocation with event evidence.

Usage:
    python -m tools.probe_agent_tools

By default this script asks the agent to inspect the workspace and read
`prompts/p_blind.md`, then captures session events and writes a proof artifact:

    results/agent-tool-proof/<timestamp>/proof.json

The artifact includes event types and extracted `tool.execution_*` entries.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from copilot import CopilotClient
from copilot.session import PermissionHandler


ROOT = Path(__file__).resolve().parent.parent
DEFAULT_WORKSPACE = str(ROOT)
DEFAULT_PROMPT = (
    "You are an autonomous coding agent. "
    "Use tools to inspect workspace /home/v-yongtao/obs-real-bench. "
    "Find prompts/p_blind.md, then return: "
    "(a) exact first non-empty line in that file, "
    "(b) number of files directly under prompts/. "
    "Do not answer from memory; use tools."
)


@dataclass
class ToolEvent:
    type: str
    tool_name: Optional[str] = None
    tool_call_id: Optional[str] = None
    mcp_server_name: Optional[str] = None
    mcp_tool_name: Optional[str] = None
    progress_message: Optional[str] = None
    partial_output: Optional[str] = None


def _pick_token() -> Optional[str]:
    for key in (
        "OBS_COPILOT_GITHUB_TOKEN",
        "COPILOT_GITHUB_TOKEN",
        "GH_TOKEN",
        "GITHUB_TOKEN",
    ):
        token = os.environ.get(key)
        if token:
            return token
    return None


def _event_type_str(event: Any) -> str:
    event_type = getattr(event, "type", "")
    if hasattr(event_type, "value"):
        return str(event_type.value)
    return str(event_type)


def _short(s: Optional[str], *, limit: int = 200) -> Optional[str]:
    if s is None:
        return None
    if len(s) <= limit:
        return s
    return s[:limit] + "..."


def _to_tool_event(event: Any) -> ToolEvent:
    data = getattr(event, "data", None)
    return ToolEvent(
        type=_event_type_str(event),
        tool_name=getattr(data, "tool_name", None),
        tool_call_id=getattr(data, "tool_call_id", None),
        mcp_server_name=getattr(data, "mcp_server_name", None),
        mcp_tool_name=getattr(data, "mcp_tool_name", None),
        progress_message=_short(getattr(data, "progress_message", None)),
        partial_output=_short(getattr(data, "partial_output", None)),
    )


def _is_toolish(event_type: str) -> bool:
    return (
        event_type.startswith("tool.")
        or event_type.startswith("external_tool.")
        or event_type in ("command.execute", "command.completed")
    )


async def _run_probe(*, model: str, working_directory: str, prompt: str) -> dict[str, Any]:
    token = _pick_token()
    if not token:
        raise RuntimeError(
            "No GitHub token found. Set one of: "
            "OBS_COPILOT_GITHUB_TOKEN, COPILOT_GITHUB_TOKEN, GH_TOKEN, GITHUB_TOKEN."
        )

    async with CopilotClient() as client:
        session = await client.create_session(
            on_permission_request=PermissionHandler.approve_all,
            model=model,
            working_directory=working_directory,
            github_token=token,
        )
        async with session:
            response = await session.send_and_wait(prompt)
            events = await session.get_events()

    event_types = [_event_type_str(e) for e in events]
    tool_events = [_to_tool_event(e) for e in events if _is_toolish(_event_type_str(e))]
    tool_names = sorted({e.tool_name for e in tool_events if e.tool_name})

    return {
        "model": model,
        "working_directory": working_directory,
        "prompt": prompt,
        "response_preview": _short(str(response), limit=1000),
        "events_total": len(events),
        "event_types_unique": sorted(set(event_types)),
        "tool_events_total": len(tool_events),
        "tool_names": tool_names,
        "tool_events": [asdict(e) for e in tool_events],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Probe Copilot agent tool invocation.")
    parser.add_argument("--model", default="gpt-4.1", help="Copilot model id (default: gpt-4.1)")
    parser.add_argument(
        "--working-directory",
        default=DEFAULT_WORKSPACE,
        help="Workspace path exposed to the agent",
    )
    parser.add_argument(
        "--prompt",
        default=DEFAULT_PROMPT,
        help="Probe prompt. Keep this tool-focused to trigger tool usage.",
    )
    parser.add_argument(
        "--allow-zero-tool-events",
        action="store_true",
        help="Do not fail if no tool events are observed.",
    )
    args = parser.parse_args()

    payload = asyncio.run(
        _run_probe(
            model=args.model,
            working_directory=args.working_directory,
            prompt=args.prompt,
        )
    )

    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_dir = ROOT / "results" / "agent-tool-proof" / run_id
    out_dir.mkdir(parents=True, exist_ok=True)
    out_file = out_dir / "proof.json"
    out_file.write_text(json.dumps(payload, indent=2) + "\n")

    print(f"[probe] proof file: {out_file}")
    print(f"[probe] events_total={payload['events_total']}")
    print(f"[probe] tool_events_total={payload['tool_events_total']}")
    print(f"[probe] tool_names={payload['tool_names']}")

    if payload["tool_events_total"] == 0 and not args.allow_zero_tool_events:
        print("[probe] no tool events captured; treat as non-proof run")
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
