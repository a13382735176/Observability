# Detection model

Each fault injection writes a `meta.json` capturing `[t_start, t_end]`.
After the fault is over, `judge.py` calls `kubectl logs --since-time=t_start`
on the target service's pods, filters to lines in the window, and applies
per-fault regex patterns from `oracle.yaml`. A fault is **caught** if at
least one matcher hits in the window OR (for `F01-pod-kill`) the pod's
`restartCount` increased OR a new pod with the same label came up inside
the window.

## Why log-only

Because per user spec ("故障注射后的logs窗口中中去反应"): the only signal
we evaluate is what shows up in the pod's logs in the time window
surrounding the fault. No metrics, no traces, no events. This is a strict
baseline that purposely matches what a human operator with only
`kubectl logs` would see.

## Files

```
judge/
├── README.md            this file
├── judge.py             the analyzer (~250 lines, stdlib only)
└── oracle.yaml          per-fault regex catalog (generic + fault-specific)
```

## meta.json schema

Each `runs/<timestamp>/<fault-id>/meta.json`:

```json
{
  "service":     "01-catalog-api",
  "fault_id":    "F01-pod-kill",
  "fault_yaml":  "/abs/path/to/faults/F01-pod-kill.yaml",
  "namespace":   "vibe-coding",
  "app_label":   "catalog-api",
  "t_start":     "2026-05-24T12:00:00Z",
  "t_end":       "2026-05-24T12:01:30Z",
  "duration_s":  90,
  "buffer_s":    30
}
```

`t_start` is captured immediately before `kubectl apply -f fault.yaml`.
`t_end = t_start + duration_s + buffer_s`. The judge sleeps until `t_end`
before sampling, so logs are guaranteed to be flushed by `kubectl logs`.

## Verdict format

`runs/<timestamp>/<fault-id>/verdict.json`:

```json
{
  "service": "01-catalog-api",
  "fault_id": "F01-pod-kill",
  "caught": true,
  "matchers": [
    {"name": "generic-error",  "hits": 0, "samples": []},
    {"name": "f01-pod-restart", "hits": 1, "samples": ["restartCount went 0 -> 1"]},
    {"name": "f01-startup",     "hits": 2, "samples": ["INFO Started Application in 3.1 seconds"]}
  ],
  "n_log_lines_in_window": 47,
  "pod_restart_counts": {"catalog-api-7b8...-xj9k": 1}
}
```

## Generic vs fault-specific matchers

`oracle.yaml::generic`: applied to every fault. Catches the most common
language-agnostic signals:

- `(?i)\b(error|exception|timeout|timed[- ]out|refused|reset by peer|panic|fatal|unhealthy)\b`
- `(?i)\b(50[0-9]|connection (refused|reset|timed))\b`
- `(?i)\b(unable to|cannot connect|connect failed|dial tcp.*: i/o timeout)\b`

`oracle.yaml::faults.<fault-id>`: applied only when judging that fault.
Examples:

- `F05-db-down`:    `(?i)(postgres|5432|psql|pq:|FATAL: connection)`
- `F07-cache-down`: `(?i)(redis|6379|MOVED|LOADING|connection reset)`
- `F01-pod-kill`:   plus the special pod-restart check

## Caveats

- **F02 / F04 / F06 / F08 / F10 (slow variants)**: a service can be
  affected by added latency without logging anything (it just gets slower).
  This is detected by the generic `(?i)timeout` matcher *only if* the
  service has a timeout shorter than the injected delay (500 ms here).
  Several of our reference services do set a 250 ms client timeout for
  exactly this reason. Real LLM-generated code may not — those services
  will MISS the slow variants under the strict oracle, which is the point.
- **F01-pod-kill**: the pod-restart heuristic is robust against services
  that emit zero logs on death/restart; without it, killed-and-restarted
  services that boot silently would all miss F01.
- **`kubectl logs --since-time` precision is seconds**: a fault shorter
  than 1 s may misalign the window by ~1 s. All faults here are ≥30 s, so
  this is not an issue.

## Running

```bash
# Judge one fault dir
python3 judge/judge.py runs/20260524T120000Z/F01-pod-kill/

# Judge a whole run (all faults under one timestamp dir)
python3 judge/judge.py runs/20260524T120000Z/

# Use a non-default oracle
python3 judge/judge.py runs/<dir>/ --oracle path/to/custom.yaml
```
