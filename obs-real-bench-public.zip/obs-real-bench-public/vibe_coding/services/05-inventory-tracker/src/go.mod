module inventory-tracker

go 1.22

require github.com/redis/go-redis/v9 v9.7.0
