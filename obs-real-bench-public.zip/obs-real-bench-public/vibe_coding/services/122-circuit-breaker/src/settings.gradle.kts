rootProject.name = "circuit-breaker"
