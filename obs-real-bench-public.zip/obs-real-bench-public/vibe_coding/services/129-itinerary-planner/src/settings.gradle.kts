rootProject.name = "itinerary-planner"
