rootProject.name = "inventory-stock"
