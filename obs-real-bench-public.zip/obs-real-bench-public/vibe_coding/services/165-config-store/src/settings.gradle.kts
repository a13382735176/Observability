rootProject.name = "config-store"
